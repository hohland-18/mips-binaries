#!/bin/sh
ip6=`ip -6 addr list scope  global  br0 | sed -n 's/.*inet6 \([0-9a-f:]\+\).*/\1/p'`
./ciadpi -p 8888 -q1 -r25+s > /dev/null &
./tcpfwd [$ip6]:45678 0.0.0.0:8888 -o -d > /dev/null &
exit 0
