#!/bin/sh
ip6=`ip -6 addr list scope  global  br0 | sed -n 's/.*inet6 \([0-9a-f:]\+\).*/\1/p'`
./ciadpi -i :: -p 8888 -q1 -r25+s > /dev/null &
echo IPv6 address for socks5 clients $ip6 port 8888
exit 0