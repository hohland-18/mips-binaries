#!/bin/sh

export BIND_PORT=12345
export PIDFILE=/var/run/red.pid
export ROOTPATH=/tmp/shares/sda/B/bin
export RED_BIN=$ROOTPATH/redsocks2
export LOCAL_INTERFACE="br0"

start() {
  if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE); then
    echo 'Redsocks2 is already running' >&2
    return 1
  fi

  for IFACE in $LOCAL_INTERFACE; do
    echo "Bind to local interface: $IFACE"
  done

  $RED_BIN -c $ROOTPATH/redsocks.conf -p $PIDFILE

  firewall_start_v4

  echo 'Started redsocks2'
}

stop() {
  firewall_stop_v4

  if [ ! -f "$PIDFILE" ] || ! kill -0 $(cat "$PIDFILE"); then
    echo 'Redsocks2 is not running' >&2
    return 1
  fi

  echo 'Stopping redsocks2 ...'
  kill -15 $(cat "$PIDFILE") && rm -f "$PIDFILE"
}

reload() {
  if [ ! -f "$PIDFILE" ] || ! kill -0 $(cat "$PIDFILE"); then
    echo 'Service redsocks2 is not running' >&2
    return 1
  fi

  echo 'Reloading redsocks2 service...'
  kill -1 $(cat "$PIDFILE")
}

firewall_start_v4() {
  if [ -z "$(iptables-save 2>/dev/null | grep "to-ports $BIND_PORT$")" ]; then
    for IFACE in $LOCAL_INTERFACE; do
      iptables -t nat -A PREROUTING -i $IFACE -p tcp --dport 80 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -A PREROUTING -i $IFACE -p tcp --dport 443 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -D PRE_MGNT_LAN -i br0 -p tcp -m tcp --dport 443 -j DNAT --to-destination :443
    done
  fi
}

firewall_stop_v4() {
  if [ -n "$(iptables-save 2>/dev/null | grep "to-ports $BIND_PORT$")" ]; then
    for IFACE in $LOCAL_INTERFACE; do
      iptables -t nat -D PREROUTING -i $IFACE -p tcp --dport 80 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -D PREROUTING -i $IFACE -p tcp --dport 443 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -A PRE_MGNT_LAN -i br0 -p tcp -m tcp --dport 443 -j DNAT --to-destination :443
    done
  fi
}

status() {
  if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE); then
    echo 'Service redsocks2 is running'
  else
    echo 'Service redsocks2 is stopped'
  fi
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  status)
    status
    ;;
  restart)
    stop
    start
    ;;
  reload)
    reload
    ;;
  firewall-iptables)
    firewall_start_v4
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|reload|status}"
esac
