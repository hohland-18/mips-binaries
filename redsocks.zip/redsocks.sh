#!/bin/sh

export BIND_PORT=12345
export PIDFILE=/var/run/red.pid
export ROOTPATH=/tmp/shares/sda/B
export RED_BIN=$ROOTPATH/bin/redsocks2
export LOCAL_INTERFACE="br0"
export RED_CONF=$ROOTPATH/etc/redsocks.conf
export CIA_BIN=$ROOTPATH/bin/ciadpi

ciadpi() {
  count=$(ps aux | pidof ciadpi | wc -l)
  if [ "$count" -eq 1 ]
  then {
        exit 0
       }
  else
      {
        sleep 1
        $CIA_BIN -i :: -p 8888 -o1 -o25+s > /dev/null &
      }
 fi
}

start() {
  if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE); then
    echo 'Redsocks2 is already running' >&2
    return 1
  fi

  for IFACE in $LOCAL_INTERFACE; do
    echo "Bind to local interface: $IFACE"
  done

  $RED_BIN -c $RED_CONF -p $PIDFILE
  firewall_start_v4

  echo 'Started redsocks2'
}

stop() {

  killall ciadpi
  firewall_stop_v4

  if [ ! -f "$PIDFILE" ] || ! kill -0 $(cat "$PIDFILE"); then
    echo 'Redsocks2 is not running' >&2
    return 1
  fi

  echo 'Stopping redsocks2 ...'
  kill -15 $(cat "$PIDFILE") && rm -f "$PIDFILE"
}

firewall_start_v4() {
  if [ -z "$(iptables-save 2>/dev/null | grep "to-ports $BIND_PORT$")" ]; then
    for IFACE in $LOCAL_INTERFACE; do
      iptables -t nat -A PREROUTING -i $IFACE -p tcp --dport 80 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -A PREROUTING -i $IFACE -p tcp --dport 443 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -D PRE_MGNT_LAN -i br0 -p tcp -m tcp --dport 443 -j DNAT --to-destination :443
    done
  fi
}

firewall_stop_v4() {
  if [ -n "$(iptables-save 2>/dev/null | grep "to-ports $BIND_PORT$")" ]; then
    for IFACE in $LOCAL_INTERFACE; do
      iptables -t nat -D PREROUTING -i $IFACE -p tcp --dport 80 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -D PREROUTING -i $IFACE -p tcp --dport 443 -j REDIRECT --to-port $BIND_PORT
      iptables -t nat -A PRE_MGNT_LAN -i br0 -p tcp -m tcp --dport 443 -j DNAT --to-destination :443
    done
  fi
}

status() {
  if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE); then
    echo 'Service redsocks2 is running'
  else
    echo 'Service redsocks2 is stopped'
  fi
}

case "$1" in
  start)
    ciadpi
    start
    ;;
  stop)
    stop
    ;;
  status)
    status
    ;;
  restart)
    stop
    start
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status}"
esac
